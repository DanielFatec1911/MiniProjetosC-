﻿using BuilderPattern.Builders;

namespace BuilderPattern.director
{
    public class Director
    {
        private readonly IBuilder _builder;

        public Director(IBuilder builder)
        {
            _builder = builder;
        }

        public void ConstructSedanCar()
        {
            _builder.Reset();
            _builder.SetVehicleType(VehicleType.SEDAN);
            _builder.SetEngine(new Engine(120));
            _builder.SetTransmission(Transmission.AUTOMATIC);
            _builder.SetSeats(5);
        }

        public void ConstructTruck()
        {
            _builder.Reset();
            _builder.SetVehicleType(VehicleType.TRUCK);
            _builder.SetEngine(new Engine(300));
            _builder.SetTransmission(Transmission.MANUAL);
            _builder.SetSeats(2);
        }

        public void ConstructSUV()
        {
            _builder.Reset();
            _builder.SetVehicleType(VehicleType.SUV);
            _builder.SetEngine(new Engine(260));
            _builder.SetTransmission(Transmission.AUTOMATIC_SEQUENTIAL);
            _builder.SetSeats(5);
            _builder.SetAirbag(true);
        }
    }
}
