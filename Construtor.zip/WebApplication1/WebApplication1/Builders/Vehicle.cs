﻿namespace BuilderPattern.Builders
{
    public class Vehicle
    {
        public VehicleType Type { get; set; }
        public Engine Engine { get; set; }
        public Transmission Transmission { get; set; }
        public int Seats { get; set; }
        public bool HasAirbag { get; set; } // Adicionado para o exercício 5

        public override string ToString()
        {
            return $"Type: {Type}, Engine: {Engine.Power} HP, Transmission: {Transmission}, Seats: {Seats}, Airbag: {HasAirbag}";
        }
    }
}
