﻿namespace BuilderPattern.Builders
{
    public class CarBuilder : IBuilder
    {
        private Vehicle _vehicle;

        public CarBuilder()
        {
            Reset();
        }

        public void Reset()
        {
            _vehicle = new Vehicle();
        }

        public void SetVehicleType(VehicleType vehicleType)
        {
            _vehicle.Type = vehicleType;
        }

        public void SetEngine(Engine engine)
        {
            _vehicle.Engine = engine;
        }

        public void SetTransmission(Transmission transmission)
        {
            _vehicle.Transmission = transmission;
        }

        public void SetSeats(int seats)
        {
            _vehicle.Seats = seats;
        }

        public void SetAirbag(bool hasAirbag) // Adicionado para o SUV
        {
            _vehicle.HasAirbag = hasAirbag;
        }

        public Vehicle GetVehicle()
        {
            return _vehicle;
        }
    }
}
