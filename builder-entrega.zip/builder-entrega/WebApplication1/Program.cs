using System;
using BuilderPattern.Builders;
using BuilderPattern.director;

namespace BuilderPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            CarBuilder builder = new CarBuilder();
            Director director = new Director(builder);

            // Sedan
            director.ConstructSedanCar();
            Vehicle sedan = builder.GetVehicle();
            Console.WriteLine("Sedan constru�do: " + sedan);

  
            director.ConstructTruck();
            Vehicle truck = builder.GetVehicle();
            Console.WriteLine("Caminh�o constru�do: " + truck);

            
            director.ConstructSUV();
            Vehicle suv = builder.GetVehicle();
            Console.WriteLine("SUV constru�do: " + suv);
        }
    }
}
