﻿using System;

public interface Prototype
{
    void DisplayInfo();
    Prototype Clone();
}

class Person : Prototype
{
    public string Name;
    public int Age;
    public string HairColor;
    public double Height;


    public Person(string name, int age, string hairColor, double height)
    {
        this.Name = name;
        this.Age = age;
        this.HairColor = hairColor;
        this.Height = height;
    }


    public void DisplayInfo()
    {
        Console.WriteLine("\n---- Informações do sujeito de pesquisa -----");
        Console.WriteLine($"Nome: {this.Name}" +
            $"\nIdade: {this.Age}" +
            $"\nCor do cabelo: {this.HairColor}" +
            $"\nAltura: {this.Height}m");
    }

    // Implementação do método Clone para clonar o objeto
    public Prototype Clone()
    {
        return new Person(this.Name, this.Age, this.HairColor, this.Height);
    }
}

class SecondaryProgram
{

    public Prototype GetPerson()
    {
        return new Person("Azarado 2", 17, "Castanho", 1.72);
    }
}

class Program
{
    static void Main()
    {

        SecondaryProgram secProgram = new SecondaryProgram();


        Prototype person1 = secProgram.GetPerson();
        person1.DisplayInfo();


        Prototype person2 = person1.Clone();
        person2.DisplayInfo();


        Prototype person3 = person1.Clone();
        person3.DisplayInfo();
    }
}
