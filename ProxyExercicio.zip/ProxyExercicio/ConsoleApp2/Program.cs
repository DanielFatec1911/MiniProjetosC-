﻿using System;

class Program
{
    static void Main(string[] args)
    {
        IDownloader downloader = new FileDownloaderProxy();

        while (true)
        {
            Console.WriteLine("Digite a URL do arquivo para download (ou 'sair' para encerrar):");
            string url = Console.ReadLine();

            if (url.ToLower() == "sair")
                break;

            downloader.DownloadFile(url);
            Console.WriteLine();
        }

        Console.WriteLine("Encerrando o programa...");
    }
}
