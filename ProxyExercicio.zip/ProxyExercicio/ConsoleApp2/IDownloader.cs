﻿public interface IDownloader
{
    void DownloadFile(string url);
}
