﻿using System;
using System.Collections.Generic;

public class FileDownloaderProxy : IDownloader
{
    private FileDownloadService _realService;
    private Dictionary<string, bool> _cache;

    public FileDownloaderProxy()
    {
        _realService = new FileDownloadService();
        _cache = new Dictionary<string, bool>();
    }

    public void DownloadFile(string url)
    {
        if (_cache.ContainsKey(url))
        {
            Console.WriteLine("Arquivo já foi baixado anteriormente. Usando o cache.");
            return;
        }

        Console.WriteLine($"Deseja fazer o download do arquivo {url}? (s/n)");
        string resposta = Console.ReadLine();

        if (resposta?.ToLower() != "s")
        {
            Console.WriteLine("Download cancelado pelo usuário.");
            return;
        }

        _realService.DownloadFile(url);
        _cache[url] = true;
    }
}
