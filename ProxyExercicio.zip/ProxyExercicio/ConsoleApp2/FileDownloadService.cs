﻿using System;

public class FileDownloadService : IDownloader
{
    public void DownloadFile(string url)
    {
        Console.WriteLine($"Baixando o arquivo de: {url}");
        // Simula o download com uma espera
        System.Threading.Thread.Sleep(1000);
        Console.WriteLine("Download concluído.");
    }
}
