﻿namespace BuilderPattern
{
    public interface Builder
    {
        void Reset();
        void SetVehicleType(VehicleType vehicleType);
        void SetEngine(Engine engine);
        void SetTransmission(Transmission transmission);
        void SetSeats(int seats);
        void SetAirbag(bool hasAirbag); // Adicionado para o SUV
        Vehicle GetVehicle();
    }
}
