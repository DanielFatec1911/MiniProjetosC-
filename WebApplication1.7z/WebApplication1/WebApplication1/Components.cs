﻿namespace BuilderPattern
{
    public class Engine
    {
        public int Power { get; set; }

        public Engine(int power)
        {
            Power = power;
        }
    }

    public enum Transmission
    {
        MANUAL,
        AUTOMATIC,
        AUTOMATIC_SEQUENTIAL
    }

    public enum VehicleType
    {
        SEDAN,
        SPORTCAR,
        PICKUPTRUCK,
        TRUCK,
        SUV,
        AIRBAG
    }
}
