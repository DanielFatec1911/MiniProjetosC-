using System;

namespace BuilderPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            CarBuilder builder = new CarBuilder();
            Director director = new Director(builder);

            // Criando um Sedan
            director.ConstructSedanCar();
            Vehicle sedan = builder.GetVehicle();
            Console.WriteLine("Sedan constru�do: " + sedan);

            // Criando um Caminh�o
            director.ConstructTruck();
            Vehicle truck = builder.GetVehicle();
            Console.WriteLine("Caminh�o constru�do: " + truck);

            // Criando um SUV
            director.ConstructSUV();
            Vehicle suv = builder.GetVehicle();
            Console.WriteLine("SUV constru�do: " + suv);
        }
    }
}
