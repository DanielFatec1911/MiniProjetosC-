﻿namespace BuilderPattern
{
    public interface IBuilder
    {
        void Reset();
        void SetSeats(int seats);
        void SetEngine(Engine engine);
        void SetTransmission(Transmission transmission);
        void SetVehicleType(VehicleType vehicleType);
        Vehicle GetVehicle();
    }
}
